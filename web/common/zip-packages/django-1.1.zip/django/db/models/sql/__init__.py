from datastructures import EmptyResultSet

__all__ = ['EmptyResultSet']

