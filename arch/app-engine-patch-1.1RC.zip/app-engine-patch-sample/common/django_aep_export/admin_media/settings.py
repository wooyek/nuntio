from ragendja.settings_post import settings

settings.add_uncombined_app_media('django_aep_export.admin_media')
