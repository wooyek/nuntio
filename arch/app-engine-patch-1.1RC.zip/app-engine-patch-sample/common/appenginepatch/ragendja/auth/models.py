from django.contrib.auth.models import *
from django.contrib.auth.models import DjangoCompatibleUser as User
